// Function to populate the table
function populateTable() {
    const dataTable = document.getElementById('dataTable').getElementsByTagName('tbody')[0];
    dataTable.innerHTML = ""; // Clear existing rows

    const allOpdData = JSON.parse(localStorage.getItem('allOpdData')) || {};

    for (const opd in allOpdData) {
        if (allOpdData.hasOwnProperty(opd)) {
            allOpdData[opd].forEach((item, index) => { // Access index for deletion
                let newRow = dataTable.insertRow();
                let cell1 = newRow.insertCell(0);
                let cell2 = newRow.insertCell(1);
                let cell3 = newRow.insertCell(2);
                let cell4 = newRow.insertCell(3);
                let cell5 = newRow.insertCell(4);
                let cell6 = newRow.insertCell(5);  // Actions cell

                cell1.textContent = opd; // SDP Name
                cell2.textContent = item.gender;
                cell3.textContent = item.ageRange;
                cell4.textContent = item.testResult;
                cell5.textContent = item.testDate;

                // Actions buttons
                const actionsDiv = document.createElement('div');
                actionsDiv.classList.add('action-buttons');

                // Edit button
                const editButton = document.createElement('button');
                editButton.textContent = 'Edit';
                editButton.classList.add('edit-button');
                editButton.onclick = () => editData(opd, index);
                actionsDiv.appendChild(editButton);

                // Delete button
                const deleteButton = document.createElement('button');
                deleteButton.textContent = 'Delete';
                deleteButton.classList.add('delete-button');
                deleteButton.onclick = () => deleteData(opd, index);
                actionsDiv.appendChild(deleteButton);

                cell6.appendChild(actionsDiv);  // Append actions to the cell

                // Apply a subtle animation to each row
                newRow.style.opacity = 0;
                newRow.style.animation = "fadeIn 0.5s ease-in-out forwards";
            });
        }
    }
}

// Function to edit data
function editData(opd, index) {
  const allOpdData = JSON.parse(localStorage.getItem('allOpdData')) || {};
  if (allOpdData[opd] && allOpdData[opd][index]) {
      const dataToEdit = allOpdData[opd][index];

      // Populate form fields with the data to edit
      document.getElementById('opdSelect').value = opd;
      document.getElementById('gender').value = dataToEdit.gender;
      document.getElementById('ageRange').value = dataToEdit.ageRange;
      document.getElementById('testResult').value = dataToEdit.testResult;
      document.getElementById('testDate').value = dataToEdit.testDate;
      document.getElementById('currentOPD').textContent = opd;
      document.getElementById('dataEntrySection').style.display = 'block'; // Show the form

      // Replace the existing data with the edited one
      allOpdData[opd].splice(index, 1); // Remove the old item

       // Save the updated data
      localStorage.setItem('allOpdData', JSON.stringify(allOpdData));
      populateTable();

      alert('Editing data for ' + opd + ' at index ' + index + '.  Now edit the data and submit.');

  } else {
      alert("Data not found for editing.");
  }
}

// Function to delete data
function deleteData(opd, index) {
    const allOpdData = JSON.parse(localStorage.getItem('allOpdData')) || {};
    if (allOpdData[opd] && allOpdData[opd][index]) {
        if (confirm("Are you sure you want to delete this data?")) {
            allOpdData[opd].splice(index, 1); // Remove the item

            // Save the updated data
            localStorage.setItem('allOpdData', JSON.stringify(allOpdData));
            populateTable();
            alert('Data deleted.');
        }
    } else {
        alert("Data not found for deletion.");
    }
}

// OPD Selection Logic
document.getElementById('opdSelect').addEventListener('change', function() {
  const selectedOPD = this.value;
  const dataEntrySection = document.getElementById('dataEntrySection');
  const currentOPD = document.getElementById('currentOPD');

  if (selectedOPD) {
    currentOPD.textContent = selectedOPD;
    dataEntrySection.style.display = 'block'; // Show the form

    // Apply a fade-in animation to the data entry section
    dataEntrySection.style.opacity = 0;
    dataEntrySection.style.animation = "fadeIn 0.5s ease-in-out forwards"; // Use keyframe name
  } else {
    dataEntrySection.style.display = 'none';  // Hide the form
  }
});

document.getElementById('hivDataForm').addEventListener('submit', function(event) {
  event.preventDefault();

  const selectedOPD = document.getElementById('opdSelect').value; // Get the selected SDP
  if (!selectedOPD) {
    alert("Please select an SDP first.");
    return;
  }

  const gender = document.getElementById('gender').value;
  const ageRange = document.getElementById('ageRange').value;
  const testResult = document.getElementById('testResult').value;
  const testDate = document.getElementById('testDate').value;

  if (!gender || !ageRange || !testResult || !testDate) {
    alert('Please fill out all required fields.');
    return;
  }

  const formData = {
    gender: gender,
    ageRange: ageRange,
    testResult: testResult,
    testDate: testDate
  };

  // Store data for the specific SDP
  let allOpdData = JSON.parse(localStorage.getItem('allOpdData')) || {};
  if (!allOpdData[selectedOPD]) {
    allOpdData[selectedOPD] = []; // Initialize array for the SDP if it doesn't exist
  }
  allOpdData[selectedOPD].push(formData);
  localStorage.setItem('allOpdData', JSON.stringify(allOpdData));

  // Repopulate the table
  populateTable();

  alert('Data submitted and stored for ' + selectedOPD);
  document.getElementById('hivDataForm').reset();  // Clear the form
});

// Function to export data to Excel
document.getElementById('exportExcel').addEventListener('click', function() {
  const allOpdData = JSON.parse(localStorage.getItem('allOpdData')) || {};
  let allDataForExport = [];

  if (Object.keys(allOpdData).length === 0) {
      alert("No data to export.");
      return;
  }

  for (const opd in allOpdData) {
      if (allOpdData.hasOwnProperty(opd)) {
          allOpdData[opd].forEach(item => {
              allDataForExport.push({
                  SDP: opd,
                  Gender: item.gender,
                  "Age Range": item.ageRange,
                  "Test Result": item.testResult,
                  "Test Date": item.testDate
              });
          });
      }
  }


  // Create a workbook and worksheet
  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.json_to_sheet(allDataForExport);
  XLSX.utils.book_append_sheet(wb, ws, "HIV Data");

  // Convert workbook to a buffer
  const wbout = XLSX.write(wb, {
    bookType: 'xlsx',
    type: 'array'
  });

  // Create a Blob and download link
  const blob = new Blob([wbout], { type: "application/octet-stream" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "hiv_data_all_sdps.xlsx";  // Filename
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);  // Clean up the URL
});


// Initial table population on page load
populateTable();